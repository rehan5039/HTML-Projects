import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_mobile_ads/google_mobile_ads.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:flutter_material_design_icons/flutter_material_design_icons.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  MobileAds.instance.initialize();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gmail Alias Generator',
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: Colors.blue),
        useMaterial3: true,
        textTheme: GoogleFonts.poppinsTextTheme(),
      ),
      home: const GmailAliasGeneratorScreen(),
    );
  }
}

class GmailAliasGeneratorScreen extends StatefulWidget {
  const GmailAliasGeneratorScreen({super.key});

  @override
  State<GmailAliasGeneratorScreen> createState() => _GmailAliasGeneratorScreenState();
}

class _GmailAliasGeneratorScreenState extends State<GmailAliasGeneratorScreen> {
  final TextEditingController _emailController = TextEditingController();
  final List<String> _generatedAliases = [];
  bool _showWelcomeCard = true;
  BannerAd? _bannerAd;
  SharedPreferences? _prefs;
  bool _isLoading = false;
  
  // Common prefixes for generating email variations
  final List<String> _commonPrefixes = [
    'the', 'mr', 'ms', 'dr', 'real', 'official', 'its', 'im', 'original',
    'contact', 'business', 'pro', 'premium', 'vip', 'main', 'my', 'our',
    'your', 'their', 'his', 'her', 'its', 'cool', 'best', 'top', 'prime',
    'elite', 'super', 'ultra', 'mega', 'max', 'mini', 'global', 'local',
    'world', 'web', 'net', 'cyber', 'digital', 'smart', 'tech', 'first',
    'last', 'next', 'new', 'old', 'young', 'fresh', 'true', 'pure', 'just',
    'only', 'all', 'every'
  ];

  // Common suffixes for generating email variations
  final List<String> _commonSuffixes = [
    'work', 'home', 'office', 'personal', 'private', 'public', 'secure',
    'backup', 'archive', 'temp', 'alt', 'aux', 'extra', 'spare', 'other',
    'more', 'plus', 'next', 'two', 'too', 'also', 'another', 'second',
    'third', 'last', 'end', 'final', 'finish', 'done', 'complete', 'full',
    'social', 'shopping', 'gaming', 'business', 'work', 'school', 'college',
    'uni', 'job', 'career', 'prof', 'official', 'formal', 'casual', 'family',
    'friend', 'group', 'team', 'club', 'org', 'company', 'corp', 'inc',
    'service', 'support', 'help', 'info', 'contact', 'admin', 'mail', 'post',
    'box', 'notify', 'alert', 'update', 'news', 'letter', 'subscribe',
    'member', 'user', 'client', 'customer', 'guest', 'visitor', 'account',
    'profile', 'id', 'login', 'access', 'web', 'net', 'online', 'digital',
    'cyber', 'tech', 'dev', 'test', 'demo', 'trial', 'beta', 'alpha',
    'v1', 'v2', 'pro', 'plus', 'premium', 'vip', 'special', 'prime',
    'elite', 'top', 'best', 'first', 'one', 'main', 'primary', 'principal',
    'chief', 'head', 'lead', 'senior', 'junior', 'assistant', 'helper',
    'backup', 'reserve', 'spare', 'extra', 'additional', 'more', 'another',
    'alt', 'other', 'else', 'misc', 'various', 'diverse', 'different',
    'unique', 'special', 'specific', 'particular', 'certain', 'selected',
    'chosen', 'picked', 'preferred', 'favored', 'liked', 'trusted',
    'verified', 'confirmed', 'approved', 'accepted', 'allowed', 'permitted',
    'authorized', 'certified', 'registered', 'enrolled', 'listed', 'included',
    'added', 'joined', 'connected', 'linked', 'related', 'associated',
    'affiliated', 'partner', 'ally', 'friend', 'buddy', 'pal', 'mate',
    'fellow', 'peer', 'colleague', 'coworker', 'associate', 'contact',
    'connection', 'network', 'group', 'circle', 'community', 'society',
    'club', 'organization', 'association', 'federation', 'union', 'alliance',
    'league', 'guild', 'crew', 'squad', 'team', 'unit', 'division',
    'section', 'department', 'branch', 'region', 'zone', 'area'
  ];

  @override
  void initState() {
    super.initState();
    _initPrefs();
    _loadAd();
  }

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    _loadPreferences();
  }

  void _loadPreferences() {
    if (_prefs != null) {
      setState(() {
        _showWelcomeCard = _prefs!.getBool('show_welcome_card') ?? true;
      });
    }
  }

  void _loadAd() {
    _bannerAd = BannerAd(
      adUnitId: 'ca-app-pub-1825658062974153~3439028076',
      size: AdSize.banner,
      request: const AdRequest(),
      listener: BannerAdListener(
        onAdLoaded: (ad) {
          setState(() {});
        },
        onAdFailedToLoad: (ad, error) {
          ad.dispose();
        },
      ),
    )..load();
  }

  void _generateAliases() {
    if (_emailController.text.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please enter a Gmail address')),
      );
      return;
    }

    setState(() {
      _isLoading = true;
      _generatedAliases.clear();
    });

    String baseEmail = _emailController.text.replaceAll('@gmail.com', '');
    
    // Add original email
    _generatedAliases.add('$baseEmail@gmail.com');

    // Generate variations with prefixes
    for (String prefix in _commonPrefixes) {
      _generatedAliases.add('$baseEmail+$prefix@gmail.com');
    }

    // Generate variations with suffixes
    for (String suffix in _commonSuffixes) {
      _generatedAliases.add('$baseEmail+$suffix@gmail.com');
    }

    // Generate combinations
    for (String prefix in _commonPrefixes.take(10)) {
      for (String suffix in _commonSuffixes.take(10)) {
        _generatedAliases.add('$baseEmail+$prefix.$suffix@gmail.com');
      }
    }

    // Add variations with numbers
    final currentYear = DateTime.now().year;
    for (int i = 0; i < 10; i++) {
      _generatedAliases.add('$baseEmail+$currentYear$i@gmail.com');
      _generatedAliases.add('$baseEmail+${currentYear}_$i@gmail.com');
    }

    // Add timestamp variation
    _generatedAliases.add('$baseEmail+${DateTime.now().millisecondsSinceEpoch}@gmail.com');

    setState(() {
      _isLoading = false;
    });
  }

  void _copyToClipboard(String email) {
    Clipboard.setData(ClipboardData(text: email));
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Email copied to clipboard!')),
    );
  }

  Future<void> _dismissWelcomeCard() async {
    if (_prefs != null) {
      await _prefs!.setBool('show_welcome_card', false);
      setState(() {
        _showWelcomeCard = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Gmail Alias Generator'),
        backgroundColor: Theme.of(context).colorScheme.inversePrimary,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (_showWelcomeCard)
              Card(
                margin: const EdgeInsets.only(bottom: 16.0),
                color: const Color(0xFFF5F5F5),
                elevation: 4,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16),
                ),
                child: Padding(
                  padding: const EdgeInsets.all(24.0),
                  child: Column(
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.end,
                        children: [
                          IconButton(
                            icon: const Icon(Icons.close),
                            onPressed: _dismissWelcomeCard,
                            padding: const EdgeInsets.all(4),
                          ),
                        ],
                      ),
                      const Text(
                        'Welcome to Gmail Alias Generator!\n\nWith this app, you can generate Gmail aliases for multiple website sign-ups.\n\nHave fun! 🎉',
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 18,
                          color: Color(0xFF333333),
                          height: 1.5,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            TextField(
              controller: _emailController,
              decoration: const InputDecoration(
                labelText: 'Enter base Gmail address',
                hintText: 'example@gmail.com',
                border: OutlineInputBorder(),
              ),
              keyboardType: TextInputType.emailAddress,
            ),
            const SizedBox(height: 16),
            ElevatedButton(
              onPressed: _generateAliases,
              style: ElevatedButton.styleFrom(
                padding: const EdgeInsets.symmetric(vertical: 16),
              ),
              child: Text(_isLoading ? 'Generating...' : 'Generate Gmail Variations'),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _isLoading
                ? const Center(child: CircularProgressIndicator())
                : ListView.builder(
                    itemCount: _generatedAliases.length,
                    itemBuilder: (context, index) {
                      return Card(
                        margin: const EdgeInsets.symmetric(vertical: 4),
                        shape: RoundedRectangleBorder(
                          borderRadius: BorderRadius.circular(8),
                        ),
                        elevation: 2,
                        child: ListTile(
                          title: Text(
                            _generatedAliases[index],
                            style: const TextStyle(fontSize: 16),
                          ),
                          trailing: IconButton(
                            icon: const Icon(MdiIcons.contentCopy),
                            onPressed: () => _copyToClipboard(_generatedAliases[index]),
                          ),
                        ),
                      );
                    },
                  ),
            ),
            if (_bannerAd != null)
              Container(
                alignment: Alignment.center,
                width: _bannerAd!.size.width.toDouble(),
                height: _bannerAd!.size.height.toDouble(),
                child: AdWidget(ad: _bannerAd!),
              ),
          ],
        ),
      ),
    );
  }

  @override
  void dispose() {
    _emailController.dispose();
    _bannerAd?.dispose();
    super.dispose();
  }
}
