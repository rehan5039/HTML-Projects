document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const welcomeCard = document.getElementById('welcomeCard');
    const closeWelcome = document.getElementById('closeWelcome');
    const emailInput = document.getElementById('emailInput');
    const emailError = document.getElementById('emailError');
    const generateButton = document.getElementById('generateButton');
    const buttonText = generateButton.querySelector('.button-text');
    const buttonLoader = generateButton.querySelector('.button-loader');
    const emailList = document.getElementById('emailList');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const toast = document.getElementById('toast');
    const toastMessage = toast.querySelector('.toast-message');

    // Common prefixes and suffixes from Android app
    const commonPrefixes = [
        'the', 'mr', 'ms', 'dr', 'real', 'official', 'its', 'im', 'original',
        'contact', 'business', 'pro', 'premium', 'vip', 'main', 'my', 'our',
        'your', 'their', 'his', 'her', 'its', 'cool', 'best', 'top', 'prime',
        'elite', 'super', 'ultra', 'mega', 'max', 'mini', 'global', 'local',
        'world', 'web', 'net', 'cyber', 'digital', 'smart', 'tech', 'first',
        'last', 'next', 'new', 'old', 'young', 'fresh', 'true', 'pure', 'just',
        'only', 'all', 'every', 'info', 'help', 'support', 'admin', 'mail'
    ];

    const commonSuffixes = [
        'work', 'home', 'office', 'personal', 'social', 'private', 'public',
        'secure', 'mail', 'contact', 'info', 'admin', 'help', 'support', 'team',
        'group', 'business', 'pro', 'premium', 'vip', 'main', 'alt', 'backup',
        'archive', 'temp', 'test', 'dev', 'spam', 'nospam', 'shop', 'store',
        'sales', 'billing', 'account', 'web', 'online', 'digital', 'media',
        'marketing', 'promo', 'official', 'service', 'care', 'enquiry'
    ];

    // Welcome card functionality
    closeWelcome.addEventListener('click', function() {
        welcomeCard.style.display = 'none';
        localStorage.setItem('welcomeCardClosed', 'true');
    });

    if (localStorage.getItem('welcomeCardClosed') === 'true') {
        welcomeCard.style.display = 'none';
    }

    // Email input validation
    emailInput.addEventListener('input', function() {
        validateEmail(this.value);
    });

    emailInput.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });

    emailInput.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });

    // Email generation
    generateButton.addEventListener('click', async function() {
        const email = emailInput.value.trim().toLowerCase();
        
        // Validation
        if (!isValidGmailAddress(email)) {
            return;
        }

        // Start loading state
        setLoading(true);
        emailList.innerHTML = '';

        try {
            const username = email.split('@')[0];
            const variations = await generateAllVariations(username);
            await new Promise(resolve => setTimeout(resolve, 500)); // Minimum loading time
            displayVariations(variations);
        } catch (error) {
            console.error('Error generating variations:', error);
            showError('Error generating variations');
        } finally {
            setLoading(false);
        }
    });

    // Email validation (matches Android app exactly)
    function isValidGmailAddress(email) {
        if (!email) {
            showError('Please enter a Gmail address');
            return false;
        }

        const gmailPattern = /^[A-Za-z0-9._%+-]+@gmail\.com$/;
        if (!gmailPattern.test(email)) {
            showError('Please enter a valid Gmail address');
            return false;
        }

        const username = email.split('@')[0];
        
        // Additional validation from Android app
        if (username.length < 6) {
            showError('Email username must be at least 6 characters');
            return false;
        }

        if (username.startsWith('.') || username.endsWith('.') || username.includes('..')) {
            showError('Invalid dot placement in email');
            return false;
        }

        showError('');
        return true;
    }

    // Generate all possible email variations
    async function generateAllVariations(username) {
        const variations = new Set();
        const domain = '@gmail.com';
        const maxVariations = 500; // Limit from Android app

        // Base email
        variations.add(username + domain);

        // 1. Dot combinations (exact Android logic)
        const positions = generateDotPositions(username);
        for (const pos of positions) {
            if (variations.size >= maxVariations) break;
            let modified = username;
            let offset = 0;
            for (const p of pos) {
                modified = modified.slice(0, p + offset) + '.' + modified.slice(p + offset);
                offset++;
            }
            variations.add(modified + domain);
        }

        // 2. Prefix variations (Android app order)
        for (const prefix of commonPrefixes) {
            if (variations.size >= maxVariations) break;
            variations.add(`${prefix}${username}${domain}`);
            variations.add(`${prefix}.${username}${domain}`);
            variations.add(`${username}+${prefix}${domain}`);
        }

        // 3. Suffix variations
        for (const suffix of commonSuffixes) {
            if (variations.size >= maxVariations) break;
            variations.add(`${username}+${suffix}${domain}`);
        }

        // 4. Year variations (current + next 5 years)
        const currentYear = new Date().getFullYear();
        for (let year = currentYear; year <= currentYear + 5; year++) {
            if (variations.size >= maxVariations) break;
            variations.add(`${username}${year}${domain}`);
            variations.add(`${username}.${year}${domain}`);
            variations.add(`${username}+${year}${domain}`);
        }

        // 5. Random variations (Android app format)
        const randomCount = Math.min(10, maxVariations - variations.size);
        for (let i = 0; i < randomCount; i++) {
            variations.add(`${username}+${generateRandomString(5)}${domain}`);
        }

        // Sort and limit variations like Android app
        return Array.from(variations)
            .sort((a, b) => a.length - b.length || a.localeCompare(b))
            .slice(0, maxVariations);
    }

    // Generate dot positions (matches Android app logic exactly)
    function generateDotPositions(str) {
        const result = [];
        const n = str.length - 1;
        
        // Android app uses max 3 dots
        for (let r = 1; r <= Math.min(3, n); r++) {
            generateCombinations(n, r, [], 0, result);
        }
        
        return result;
    }

    // Helper function for generating combinations (Android app logic)
    function generateCombinations(n, r, current, pos, result) {
        if (current.length === r) {
            result.push([...current]);
            return;
        }
        
        for (let i = pos; i < n; i++) {
            // Skip if would create invalid dot placement
            if (i > 0 && i < n - 1) {
                current.push(i);
                generateCombinations(n, r, current, i + 1, result);
                current.pop();
            }
        }
    }

    // Generate random string (matches Android format)
    function generateRandomString(length) {
        const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    // Display email variations with animations
    function displayVariations(variations) {
        emailList.innerHTML = '';
        
        variations.forEach((email, index) => {
            const card = document.createElement('div');
            card.className = 'email-card';
            card.style.animationDelay = `${index * 50}ms`;
            
            const emailText = document.createElement('div');
            emailText.className = 'email-text';
            emailText.textContent = email;
            
            const copyButton = document.createElement('button');
            copyButton.className = 'copy-button';
            copyButton.innerHTML = '<span class="material-icons">content_copy</span>';
            copyButton.addEventListener('click', () => copyToClipboard(email, copyButton));
            
            card.appendChild(emailText);
            card.appendChild(copyButton);
            emailList.appendChild(card);
        });

        // Scroll to email list
        emailList.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // Copy to clipboard with visual feedback
    async function copyToClipboard(text, button) {
        try {
            await navigator.clipboard.writeText(text);
            
            // Visual feedback on button
            const icon = button.querySelector('.material-icons');
            const originalIcon = icon.textContent;
            icon.textContent = 'check';
            button.style.color = '#0f9d58';
            
            // Show toast
            showToast('Email copied to clipboard');
            
            // Reset button after delay
            setTimeout(() => {
                icon.textContent = originalIcon;
                button.style.color = '';
            }, 2000);
        } catch (err) {
            console.error('Failed to copy:', err);
            showToast('Failed to copy email');
        }
    }

    // Show/hide loading state
    function setLoading(isLoading) {
        generateButton.disabled = isLoading;
        buttonText.style.opacity = isLoading ? '0' : '1';
        buttonLoader.style.display = isLoading ? 'block' : 'none';
        loadingIndicator.style.display = isLoading ? 'flex' : 'none';
    }

    // Show error message
    function showError(message) {
        emailError.textContent = message;
        emailInput.classList.toggle('error', !!message);
    }

    // Show toast message
    function showToast(message) {
        toastMessage.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
});
