document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const welcomeCard = document.getElementById('welcomeCard');
    const closeWelcome = document.getElementById('closeWelcome');
    const emailInput = document.getElementById('emailInput');
    const emailError = document.getElementById('emailError');
    const generateButton = document.getElementById('generateButton');
    const buttonText = generateButton.querySelector('.button-text');
    const buttonLoader = generateButton.querySelector('.button-loader');
    const emailList = document.getElementById('emailList');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const toast = document.getElementById('toast');
    const toastMessage = toast.querySelector('.toast-message');

    // Common prefixes and suffixes from Android app
    const commonPrefixes = [
        'the', 'mr', 'ms', 'dr', 'real', 'official', 'its', 'im', 'original',
        'contact', 'business', 'pro', 'premium', 'vip', 'main', 'my', 'our',
        'your', 'their', 'his', 'her', 'its', 'cool', 'best', 'top', 'prime',
        'elite', 'super', 'ultra', 'mega', 'max', 'mini', 'global', 'local',
        'world', 'web', 'net', 'cyber', 'digital', 'smart', 'tech', 'first',
        'last', 'next', 'new', 'old', 'young', 'fresh', 'true', 'pure', 'just',
        'only', 'all', 'every', 'info', 'help', 'support', 'admin', 'mail',
        'lite', 'free', 'paid', 'premium', 'ultimate', 'extreme', 'max', 'mini',
        'micro', 'nano', 'alpha', 'beta', 'gamma', 'omega', 'prime', 'first',
        'last', 'next', 'new', 'old', 'ceo', 'cfo', 'cto', 'hr', 'manager',
        'head', 'lead', 'senior', 'junior', 'intern', 'trainee', 'student',
        'teacher', 'mentor', 'guide', 'expert', 'master', 'guru', 'ninja',
        'wizard', 'pro', 'noob', 'legend', 'star', 'hero'
    ];

    const commonSuffixes = [
        'work', 'home', 'office', 'personal', 'social', 'private', 'public',
        'secure', 'mail', 'contact', 'info', 'admin', 'help', 'support', 'team',
        'group', 'business', 'pro', 'premium', 'vip', 'main', 'alt', 'backup',
        'archive', 'temp', 'test', 'dev', 'spam', 'nospam', 'shop', 'store',
        'sales', 'billing', 'account', 'web', 'online', 'digital', 'media',
        'marketing', 'promo', 'official', 'service', 'care', 'enquiry',
        'india', 'usa', 'uk', 'aus', 'can', 'asia', 'euro', 'africa', 'global',
        'world', 'dev', 'developer', 'code', 'coder', 'programming', 'software',
        'hardware', 'network', 'security', 'crypto', 'web', 'app', 'mobile',
        'cloud', 'data', 'ai', 'ml', 'iot', 'blockchain', 'gaming', 'gram',
        'tweet', 'snap', 'tok', 'tube', 'book', 'link', 'chat', 'talk', 'meet',
        'live', 'stream', 'cast', 'play', 'watch', 'view', 'follow', 'share',
        'like', 'post'
    ];

    // Location-based suffixes
    const locationSuffixes = [
        'india', 'usa', 'uk', 'aus', 'can', 'asia', 'euro', 'africa', 'global',
        'world', 'local', 'region', 'zone'
    ];

    // Tech-based suffixes
    const techSuffixes = [
        'dev', 'developer', 'code', 'coder', 'programming', 'software',
        'hardware', 'network', 'security', 'crypto', 'web', 'app', 'mobile',
        'cloud', 'data', 'ai', 'ml', 'iot', 'blockchain'
    ];

    // Social media suffixes
    const socialSuffixes = [
        'gram', 'tweet', 'snap', 'tok', 'tube', 'book', 'link', 'chat',
        'talk', 'meet', 'live', 'stream', 'cast', 'play', 'watch', 'view',
        'follow', 'share', 'like', 'post'
    ];

    // Welcome card functionality
    closeWelcome.addEventListener('click', function() {
        welcomeCard.style.display = 'none';
        localStorage.setItem('welcomeCardClosed', 'true');
    });

    if (localStorage.getItem('welcomeCardClosed') === 'true') {
        welcomeCard.style.display = 'none';
    }

    // Email input validation
    emailInput.addEventListener('input', function() {
        validateEmail(this.value);
    });

    emailInput.addEventListener('focus', function() {
        this.parentElement.classList.add('focused');
    });

    emailInput.addEventListener('blur', function() {
        this.parentElement.classList.remove('focused');
    });

    // Email generation
    generateButton.addEventListener('click', async function() {
        const email = emailInput.value.trim().toLowerCase();
        
        // Validation
        if (!validateEmail(email)) {
            return;
        }

        // Start loading state
        setLoading(true);
        emailList.innerHTML = '';

        try {
            const [username] = email.split('@');
            const variations = await generateAllVariations(username);
            await new Promise(resolve => setTimeout(resolve, 500)); // Minimum loading time
            displayVariations(variations);
        } catch (error) {
            console.error('Error generating variations:', error);
            showError('Error generating variations');
        } finally {
            setLoading(false);
        }
    });

    // Email validation (exactly like Android app)
    function validateEmail(email) {
        if (!email) {
            showError('Please enter a Gmail address');
            return false;
        }

        const gmailRegex = /^[A-Za-z0-9._%+-]+@gmail\.com$/;
        if (!gmailRegex.test(email)) {
            showError('Please enter a valid Gmail address');
            return false;
        }

        if (email.startsWith('.') || email.endsWith('.') || email.includes('..')) {
            showError('Invalid dot placement in email');
            return false;
        }

        if (email.length < 6) {
            showError('Email is too short');
            return false;
        }

        showError('');
        return true;
    }

    // Generate all possible email variations
    async function generateAllVariations(username) {
        const variations = new Set();
        const domain = '@gmail.com';

        // Base email
        variations.add(username + domain);

        // 1. Dot combinations (exactly like Android app)
        const positions = [];
        for (let i = 0; i < username.length - 1; i++) {
            for (let j = i + 1; j < username.length; j++) {
                const pos = [i];
                if (j - i > 1) {
                    pos.push(j);
                }
                positions.push(pos);
            }
        }

        for (const pos of positions) {
            let modified = username;
            let offset = 0;
            for (const p of pos.sort((a, b) => a - b)) {
                modified = modified.slice(0, p + offset) + '.' + modified.slice(p + offset);
                offset++;
            }
            variations.add(modified + domain);
        }

        // 2. Prefix variations (exactly like Android app)
        for (const prefix of commonPrefixes) {
            // Basic prefix
            variations.add(`${prefix}${username}${domain}`);
            
            // Prefix with separator
            variations.add(`${prefix}.${username}${domain}`);
            variations.add(`${prefix}_${username}${domain}`);
            variations.add(`${prefix}-${username}${domain}`);
            
            // Prefix at end
            variations.add(`${username}${prefix}${domain}`);
            variations.add(`${username}.${prefix}${domain}`);
            variations.add(`${username}_${prefix}${domain}`);
            variations.add(`${username}-${prefix}${domain}`);
            
            // With numbers
            variations.add(`${prefix}${username}123${domain}`);
            variations.add(`${prefix}${username}${new Date().getFullYear()}${domain}`);
        }

        // 3. Suffix variations with categories (like Android app)
        const allSuffixes = new Set([
            ...commonSuffixes,
            ...locationSuffixes,
            ...techSuffixes,
            ...socialSuffixes
        ]);

        for (const suffix of allSuffixes) {
            // Basic suffix
            variations.add(`${username}${suffix}${domain}`);
            
            // With separators
            variations.add(`${username}.${suffix}${domain}`);
            variations.add(`${username}_${suffix}${domain}`);
            variations.add(`${username}-${suffix}${domain}`);
            variations.add(`${username}+${suffix}${domain}`);
            
            // With numbers
            variations.add(`${username}${suffix}123${domain}`);
            variations.add(`${username}${suffix}${new Date().getFullYear()}${domain}`);
            
            // Combinations
            variations.add(`${suffix}${username}${domain}`);
            variations.add(`${suffix}.${username}${domain}`);
        }

        // 4. Year variations (current year + next 5 years)
        const currentYear = new Date().getFullYear();
        for (let year = currentYear; year <= currentYear + 5; year++) {
            // Full year
            variations.add(`${username}${year}${domain}`);
            variations.add(`${year}${username}${domain}`);
            variations.add(`${username}.${year}${domain}`);
            variations.add(`${username}_${year}${domain}`);
            
            // Short year
            const shortYear = year.toString().slice(-2);
            variations.add(`${username}${shortYear}${domain}`);
            variations.add(`${shortYear}${username}${domain}`);
            variations.add(`${username}${shortYear}${domain}`);
            
            // With dot
            variations.add(`${username}.${shortYear}${domain}`);
            variations.add(`${shortYear}.${username}${domain}`);
        }

        // 5. Number combinations (like Android app)
        for (let i = 0; i <= 99; i++) {
            variations.add(`${username}${i}${domain}`);
            variations.add(`${username}.${i}${domain}`);
            variations.add(`${username}_${i}${domain}`);
            if (i < 10) {
                variations.add(`${username}0${i}${domain}`);
            }
        }

        // 6. Special character combinations (like Android app)
        const specialChars = ['.', '_', '-', '+'];
        for (const char of specialChars) {
            variations.add(`${username}${char}${generateRandomString(3)}${domain}`);
            variations.add(`${username}${char}${currentYear}${domain}`);
            variations.add(`${username}${char}${Math.floor(Math.random() * 999)}${domain}`);
        }

        // 7. Random variations with length check (like Android app)
        for (let i = 0; i < 20; i++) {
            const randomStr = generateRandomString(3);
            if (username.length + randomStr.length <= 30) { // Gmail's max length
                variations.add(`${username}${randomStr}${domain}`);
                variations.add(`${username}.${randomStr}${domain}`);
                variations.add(`${username}_${randomStr}${domain}`);
            }
        }

        // Sort by length and return
        return Array.from(variations)
            .filter(email => email.length <= 40) // Gmail's max length
            .sort((a, b) => a.length - b.length);
    }

    // Generate dot positions (matches Android app logic)
    function generateDotPositions(str) {
        const result = [];
        const n = str.length - 1;
        
        // Generate combinations of 1 to 3 dots
        for (let r = 1; r <= Math.min(3, n); r++) {
            generateCombinations(n, r, [], 0, result);
        }
        
        return result;
    }

    // Helper function for generating combinations
    function generateCombinations(n, r, current, pos, result) {
        if (current.length === r) {
            result.push([...current]);
            return;
        }
        
        for (let i = pos; i < n; i++) {
            current.push(i);
            generateCombinations(n, r, current, i + 1, result);
            current.pop();
        }
    }

    // Generate random string (enhanced version)
    function generateRandomString(length) {
        const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += chars.charAt(Math.floor(Math.random() * chars.length));
        }
        return result;
    }

    // Generate random letters only
    function generateRandomLetters(length) {
        const letters = 'abcdefghijklmnopqrstuvwxyz';
        let result = '';
        for (let i = 0; i < length; i++) {
            result += letters.charAt(Math.floor(Math.random() * letters.length));
        }
        return result;
    }

    // Display email variations with animations
    function displayVariations(variations) {
        emailList.innerHTML = '';
        
        variations.forEach((email, index) => {
            const card = document.createElement('div');
            card.className = 'email-card';
            card.style.animationDelay = `${index * 50}ms`;
            
            const emailText = document.createElement('div');
            emailText.className = 'email-text';
            emailText.textContent = email;
            
            const copyButton = document.createElement('button');
            copyButton.className = 'copy-button';
            copyButton.innerHTML = '<span class="material-icons">content_copy</span>';
            copyButton.addEventListener('click', () => copyToClipboard(email, copyButton));
            
            card.appendChild(emailText);
            card.appendChild(copyButton);
            emailList.appendChild(card);
        });

        // Scroll to email list
        emailList.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    }

    // Copy to clipboard with visual feedback
    async function copyToClipboard(text, button) {
        try {
            await navigator.clipboard.writeText(text);
            
            // Visual feedback on button
            const icon = button.querySelector('.material-icons');
            const originalIcon = icon.textContent;
            icon.textContent = 'check';
            button.style.color = '#0f9d58';
            
            // Show toast
            showToast('Email copied to clipboard');
            
            // Reset button after delay
            setTimeout(() => {
                icon.textContent = originalIcon;
                button.style.color = '';
            }, 2000);
        } catch (err) {
            console.error('Failed to copy:', err);
            showToast('Failed to copy email');
        }
    }

    // Show/hide loading state
    function setLoading(isLoading) {
        generateButton.disabled = isLoading;
        buttonText.style.opacity = isLoading ? '0' : '1';
        buttonLoader.style.display = isLoading ? 'block' : 'none';
        loadingIndicator.style.display = isLoading ? 'flex' : 'none';
    }

    // Show error message
    function showError(message) {
        emailError.textContent = message;
        emailInput.classList.toggle('error', !!message);
    }

    // Show toast message
    function showToast(message) {
        toastMessage.textContent = message;
        toast.classList.add('show');
        
        setTimeout(() => {
            toast.classList.remove('show');
        }, 3000);
    }
});
