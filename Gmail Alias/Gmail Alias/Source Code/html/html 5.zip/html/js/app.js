document.addEventListener('DOMContentLoaded', function() {
    // DOM Elements
    const welcomeCard = document.getElementById('welcomeCard');
    const closeWelcomeBtn = document.getElementById('closeWelcome');
    const emailInput = document.getElementById('emailInput');
    const generateButton = document.getElementById('generateButton');
    const emailList = document.getElementById('emailList');
    const copyAllButton = document.getElementById('copyAllButton');
    const downloadButton = document.getElementById('downloadButton');
    const loadingIndicator = document.getElementById('loadingIndicator');
    const statsCard = document.getElementById('statsCard');
    const toast = document.getElementById('toast');

    // Stats Elements
    const totalAliasesEl = document.getElementById('totalAliases');
    const dotCountEl = document.getElementById('dotCount');
    const prefixCountEl = document.getElementById('prefixCount');
    const suffixCountEl = document.getElementById('suffixCount');

    // Settings Elements
    const dotVariationsCheck = document.getElementById('dotVariations');
    const prefixVariationsCheck = document.getElementById('prefixVariations');
    const suffixVariationsCheck = document.getElementById('suffixVariations');
    const yearVariationsCheck = document.getElementById('yearVariations');
    const maxVariationsSlider = document.getElementById('maxVariations');
    const maxVariationsValue = document.getElementById('maxVariationsValue');

    // Constants
    const PREFIXES = ['info', 'contact', 'admin', 'support', 'sales', 'marketing', 'dev', 'help', 'no-reply', 'noreply'];
    const SUFFIXES = ['work', 'business', 'personal', 'private', 'public', 'office', 'mail', 'contact', 'web', 'online'];
    const YEARS = ['2024', '2025', '23', '24', '25'];

    // Event Listeners
    closeWelcomeBtn.addEventListener('click', () => {
        welcomeCard.style.display = 'none';
        localStorage.setItem('welcomeCardClosed', 'true');
    });

    emailInput.addEventListener('input', validateEmail);
    generateButton.addEventListener('click', generateAliases);
    copyAllButton.addEventListener('click', copyAllEmails);
    downloadButton.addEventListener('click', downloadEmails);
    maxVariationsSlider.addEventListener('input', updateMaxVariationsValue);

    // Check if welcome card should be shown
    if (localStorage.getItem('welcomeCardClosed')) {
        welcomeCard.style.display = 'none';
    }

    // Functions
    function validateEmail() {
        const email = emailInput.value.trim();
        const errorEl = document.getElementById('emailError');
        const isValid = email.endsWith('@gmail.com') && email.length > 10;
        
        if (!email) {
            errorEl.textContent = '';
            generateButton.disabled = true;
            return false;
        }
        
        if (!isValid) {
            errorEl.textContent = 'Please enter a valid Gmail address';
            generateButton.disabled = true;
            return false;
        }
        
        errorEl.textContent = '';
        generateButton.disabled = false;
        return true;
    }

    function updateMaxVariationsValue() {
        maxVariationsValue.textContent = maxVariationsSlider.value;
    }

    function showLoading(show) {
        loadingIndicator.style.display = show ? 'flex' : 'none';
        generateButton.disabled = show;
        const btnContent = generateButton.querySelector('.btn-content');
        const btnText = btnContent.querySelector('.btn-text');
        const btnLoader = btnContent.querySelector('.btn-loader');
        
        if (show) {
            btnText.style.opacity = '0';
            btnLoader.style.display = 'block';
        } else {
            btnText.style.opacity = '1';
            btnLoader.style.display = 'none';
        }
    }

    function showToast(message) {
        const toastMessage = toast.querySelector('.toast-message');
        toastMessage.textContent = message;
        toast.classList.add('show');
        setTimeout(() => toast.classList.remove('show'), 3000);
    }

    function generateDotVariations(username) {
        const variations = new Set();
        const chars = username.split('');
        const n = chars.length;
        
        // Generate all possible dot combinations
        for (let i = 0; i < (1 << (n - 1)); i++) {
            let variation = chars[0];
            for (let j = 1; j < n; j++) {
                if (i & (1 << (j - 1))) variation += '.';
                variation += chars[j];
            }
            variations.add(variation);
        }
        
        return Array.from(variations);
    }

    function generatePrefixVariations(username) {
        return PREFIXES.map(prefix => `${prefix}.${username}`);
    }

    function generateSuffixVariations(username) {
        return SUFFIXES.map(suffix => `${username}.${suffix}`);
    }

    function generateYearVariations(username) {
        return YEARS.map(year => `${username}${year}`);
    }

    function generateAliases() {
        if (!validateEmail()) return;
        
        showLoading(true);
        statsCard.style.display = 'block';
        emailList.innerHTML = '';
        
        const email = emailInput.value.trim();
        const username = email.split('@')[0];
        const domain = email.split('@')[1];
        const maxVariations = parseInt(maxVariationsSlider.value);
        
        setTimeout(() => {
            const variations = new Set();
            let stats = {
                dots: 0,
                prefix: 0,
                suffix: 0,
                year: 0
            };
            
            // Generate variations based on selected options
            if (dotVariationsCheck.checked) {
                const dotVars = generateDotVariations(username);
                dotVars.forEach(v => variations.add(`${v}@${domain}`));
                stats.dots = dotVars.length;
            }
            
            if (prefixVariationsCheck.checked) {
                const prefixVars = generatePrefixVariations(username);
                prefixVars.forEach(v => variations.add(`${v}@${domain}`));
                stats.prefix = prefixVars.length;
            }
            
            if (suffixVariationsCheck.checked) {
                const suffixVars = generateSuffixVariations(username);
                suffixVars.forEach(v => variations.add(`${v}@${domain}`));
                stats.suffix = suffixVars.length;
            }
            
            if (yearVariationsCheck.checked) {
                const yearVars = generateYearVariations(username);
                yearVars.forEach(v => variations.add(`${v}@${domain}`));
                stats.year = yearVars.length;
            }
            
            // Limit variations to max value
            const finalVariations = Array.from(variations).slice(0, maxVariations);
            
            // Update stats
            totalAliasesEl.textContent = finalVariations.length;
            dotCountEl.textContent = stats.dots;
            prefixCountEl.textContent = stats.prefix;
            suffixCountEl.textContent = stats.suffix;
            
            // Display variations
            finalVariations.forEach(variation => {
                const card = document.createElement('div');
                card.className = 'email-card';
                
                const emailText = document.createElement('span');
                emailText.className = 'email-text';
                emailText.textContent = variation;
                
                const copyBtn = document.createElement('button');
                copyBtn.className = 'action-btn';
                copyBtn.innerHTML = '<span class="material-icons-round">content_copy</span>';
                copyBtn.addEventListener('click', () => {
                    navigator.clipboard.writeText(variation)
                        .then(() => showToast('Email copied to clipboard!'))
                        .catch(() => showToast('Failed to copy email'));
                });
                
                card.appendChild(emailText);
                card.appendChild(copyBtn);
                emailList.appendChild(card);
            });
            
            showLoading(false);
        }, 500);
    }

    function copyAllEmails() {
        const emails = Array.from(emailList.querySelectorAll('.email-text'))
            .map(el => el.textContent)
            .join('\n');
        
        if (!emails) {
            showToast('No emails to copy');
            return;
        }
        
        navigator.clipboard.writeText(emails)
            .then(() => showToast('All emails copied to clipboard!'))
            .catch(() => showToast('Failed to copy emails'));
    }

    function downloadEmails() {
        const emails = Array.from(emailList.querySelectorAll('.email-text'))
            .map(el => el.textContent)
            .join('\n');
        
        if (!emails) {
            showToast('No emails to download');
            return;
        }
        
        const blob = new Blob([emails], { type: 'text/plain' });
        const url = URL.createObjectURL(blob);
        const a = document.createElement('a');
        a.href = url;
        a.download = 'gmail-aliases.txt';
        document.body.appendChild(a);
        a.click();
        document.body.removeChild(a);
        URL.revokeObjectURL(url);
        
        showToast('Emails downloaded successfully!');
    }
});
