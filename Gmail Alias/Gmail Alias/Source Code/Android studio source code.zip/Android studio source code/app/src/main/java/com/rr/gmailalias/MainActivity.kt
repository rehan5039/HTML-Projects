package com.rr.gmailalias

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.rr.gmailalias.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val emailAdapter = EmailAdapter()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
    }

    private fun setupRecyclerView() {
        binding.emailList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = emailAdapter
        }
    }

    private fun setupClickListeners() {
        binding.closeButton.setOnClickListener {
            binding.welcomeCard.visibility = View.GONE
        }

        binding.generateButton.setOnClickListener {
            val baseEmail = binding.emailInput.text.toString()
            if (baseEmail.isEmpty() || !baseEmail.contains("@gmail.com")) {
                Toast.makeText(this, "Please enter a valid Gmail address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val username = baseEmail.substringBefore("@")
            val variations = generateGmailVariations(username)
            emailAdapter.updateEmails(variations)
        }
    }

    private fun generateGmailVariations(username: String): List<String> {
        val variations = mutableListOf<String>()
        
        // Original email
        variations.add("$username@gmail.com")
        
        // Add all possible dot variations
        generateDotCombinations(username).forEach { dotVariation ->
            variations.add("$dotVariation@gmail.com")
        }
        
        // Add extensive plus variations
        val plusAliases = listOf(
            "signup", "social", "shopping", "work", 
            "personal", "business", "banking", "bills",
            "newsletters", "spam", "important", "travel",
            "receipts", "orders", "subscriptions", "gaming",
            "entertainment", "family", "friends", "backup"
        )
        
        plusAliases.forEach { alias ->
            variations.add("$username+$alias@gmail.com")
            // Add dot variations with plus
            generateDotCombinations(username).forEach { dotVariation ->
                variations.add("$dotVariation+$alias@gmail.com")
            }
        }
        
        return variations.distinct()
    }
    
    private fun generateDotCombinations(str: String): Set<String> {
        val combinations = mutableSetOf<String>()
        
        // Generate all possible dot combinations
        for (i in 0 until (1 shl (str.length - 1))) {
            val sb = StringBuilder()
            sb.append(str[0])
            for (j in 1 until str.length) {
                if (i and (1 shl (j - 1)) != 0) {
                    sb.append('.')
                }
                sb.append(str[j])
            }
            combinations.add(sb.toString())
        }
        
        return combinations
    }
}
