package com.rr.gmailalias

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.view.animation.LayoutAnimationController
import android.widget.Toast
import androidx.activity.addCallback
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.gson.Gson
import com.google.gson.reflect.TypeToken
import com.rr.gmailalias.databinding.ActivityMainBinding

data class EmailHistory(
    val originalEmail: String,
    val variations: List<String>
)

class MainActivity : AppCompatActivity() {
    private lateinit var binding: ActivityMainBinding
    private val emailAdapter = EmailAdapter()
    private val gson = Gson()
    private val historyList = mutableListOf<EmailHistory>()
    private lateinit var buttonAnimation: Animation

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        setupRecyclerView()
        setupClickListeners()
        setupAnimations()
        loadHistory()
        
        onBackPressedDispatcher.addCallback(this) {
            AlertDialog.Builder(this@MainActivity)
                .setTitle("Exit App")
                .setMessage("Do you want to exit the app?")
                .setPositiveButton("OK") { _, _ ->
                    finish()
                }
                .setNegativeButton("Cancel", null)
                .show()
        }

        // Initial animations
        animateInitialViews()
    }

    private fun setupAnimations() {
        buttonAnimation = AnimationUtils.loadAnimation(this, R.anim.button_scale)
        
        // Setup RecyclerView animation
        val animation = LayoutAnimationController(
            AnimationUtils.loadAnimation(this, R.anim.item_animation_fall_down)
        )
        animation.delay = 0.15f
        animation.order = LayoutAnimationController.ORDER_NORMAL
        binding.emailList.layoutAnimation = animation
    }

    private fun animateInitialViews() {
        // Animate welcome card
        binding.welcomeCard.alpha = 0f
        binding.welcomeCard.translationY = -50f
        binding.welcomeCard.animate()
            .alpha(1f)
            .translationY(0f)
            .setDuration(500)
            .start()

        // Animate input layout
        binding.emailInputLayout.alpha = 0f
        binding.emailInputLayout.translationY = -30f
        binding.emailInputLayout.animate()
            .alpha(1f)
            .translationY(0f)
            .setStartDelay(300)
            .setDuration(500)
            .start()

        // Animate generate button
        binding.generateButton.alpha = 0f
        binding.generateButton.scaleX = 0.8f
        binding.generateButton.scaleY = 0.8f
        binding.generateButton.animate()
            .alpha(1f)
            .scaleX(1f)
            .scaleY(1f)
            .setStartDelay(500)
            .setDuration(300)
            .start()
    }

    private fun setupRecyclerView() {
        binding.emailList.apply {
            layoutManager = LinearLayoutManager(this@MainActivity)
            adapter = emailAdapter
        }
    }

    private fun setupClickListeners() {
        binding.closeButton.setOnClickListener {
            binding.welcomeCard.animate()
                .alpha(0f)
                .translationY(-binding.welcomeCard.height.toFloat())
                .setDuration(300)
                .withEndAction {
                    binding.welcomeCard.visibility = View.GONE
                }
                .start()
        }

        binding.generateButton.setOnClickListener { view ->
            view.startAnimation(buttonAnimation)
            
            val baseEmail = binding.emailInput.text.toString()
            if (baseEmail.isEmpty() || !baseEmail.contains("@gmail.com")) {
                shakeView(binding.emailInputLayout)
                Toast.makeText(this, "Please enter a valid Gmail address", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            // Close welcome card automatically
            if (binding.welcomeCard.visibility == View.VISIBLE) {
                binding.welcomeCard.animate()
                    .alpha(0f)
                    .translationY(-binding.welcomeCard.height.toFloat())
                    .setDuration(300)
                    .withEndAction {
                        binding.welcomeCard.visibility = View.GONE
                    }
                    .start()
            }

            val username = baseEmail.substringBefore("@")
            val variations = generateGmailVariations(username)
            emailAdapter.updateEmails(variations)
            binding.emailList.scheduleLayoutAnimation()
            
            // Save to history
            saveToHistory(baseEmail, variations)
        }
    }

    private fun shakeView(view: View) {
        val shake = ObjectAnimator.ofFloat(view, "translationX", 0f, 25f, -25f, 25f, -25f, 15f, -15f, 6f, -6f, 0f)
        shake.duration = 500
        shake.start()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        return when (item.itemId) {
            R.id.menu_view_history -> {
                showHistoryDialog()
                true
            }
            R.id.menu_clear_history -> {
                showClearHistoryConfirmation()
                true
            }
            R.id.menu_privacy -> {
                startActivity(Intent(this, PrivacyPolicyActivity::class.java))
                true
            }
            else -> super.onOptionsItemSelected(item)
        }
    }

    private fun loadHistory(): List<EmailHistory> {
        val prefs = getSharedPreferences("EmailHistory", Context.MODE_PRIVATE)
        val historyJson = prefs.getString("history", "[]")
        val type = object : TypeToken<List<EmailHistory>>() {}.type
        historyList.clear()
        historyList.addAll(gson.fromJson(historyJson, type))
        return historyList
    }

    private fun saveToHistory(originalEmail: String, variations: List<String>) {
        val history = EmailHistory(originalEmail, variations)
        historyList.add(0, history) // Add to beginning of list
        
        // Save to SharedPreferences
        val prefs = getSharedPreferences("EmailHistory", Context.MODE_PRIVATE)
        val historyJson = gson.toJson(historyList)
        prefs.edit().putString("history", historyJson).apply()
    }

    private fun showHistoryDialog() {
        if (historyList.isEmpty()) {
            Toast.makeText(this, "No history available", Toast.LENGTH_SHORT).show()
            return
        }

        val items = historyList.map { it.originalEmail }.toTypedArray()
        
        AlertDialog.Builder(this)
            .setTitle("Email History")
            .setItems(items) { _, position ->
                val selectedHistory = historyList[position]
                binding.emailInput.setText(selectedHistory.originalEmail)
                emailAdapter.updateEmails(selectedHistory.variations)
            }
            .setNegativeButton("Close", null)
            .show()
    }

    private fun showClearHistoryConfirmation() {
        AlertDialog.Builder(this)
            .setTitle("Clear History")
            .setMessage("Are you sure you want to clear all email history?")
            .setPositiveButton("Clear") { _, _ ->
                clearHistory()
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    private fun clearHistory() {
        historyList.clear()
        val prefs = getSharedPreferences("EmailHistory", Context.MODE_PRIVATE)
        prefs.edit().putString("history", "[]").apply()
        Toast.makeText(this, "History cleared", Toast.LENGTH_SHORT).show()
    }

    private fun generateGmailVariations(username: String): List<String> {
        val variations = mutableListOf<String>()
        
        // Original email
        variations.add("$username@gmail.com")
        
        // Add all possible dot variations
        generateDotCombinations(username).forEach { dotVariation ->
            variations.add("$dotVariation@gmail.com")
        }
        
        // Add extensive plus variations
        val plusAliases = listOf(
            "signup", "social", "shopping", "work", 
            "personal", "business", "banking", "bills",
            "newsletters", "spam", "important", "travel",
            "receipts", "orders", "subscriptions", "gaming",
            "entertainment", "family", "friends", "backup"
        )
        
        plusAliases.forEach { alias ->
            variations.add("$username+$alias@gmail.com")
            // Add dot variations with plus
            generateDotCombinations(username).forEach { dotVariation ->
                variations.add("$dotVariation+$alias@gmail.com")
            }
        }
        
        return variations.distinct()
    }
    
    private fun generateDotCombinations(str: String): Set<String> {
        val combinations = mutableSetOf<String>()
        
        // Generate all possible dot combinations
        for (i in 0 until (1 shl (str.length - 1))) {
            val sb = StringBuilder()
            sb.append(str[0])
            for (j in 1 until str.length) {
                if (i and (1 shl (j - 1)) != 0) {
                    sb.append('.')
                }
                sb.append(str[j])
            }
            combinations.add(sb.toString())
        }
        
        return combinations
    }
}
