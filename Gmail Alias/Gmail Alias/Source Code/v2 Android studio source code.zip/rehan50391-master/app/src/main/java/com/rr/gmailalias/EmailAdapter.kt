package com.rr.gmailalias

import android.animation.AnimatorSet
import android.animation.ObjectAnimator
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.view.HapticFeedbackConstants
import android.view.LayoutInflater
import android.view.ViewGroup
import android.view.animation.OvershootInterpolator
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.rr.gmailalias.databinding.ItemEmailBinding

class EmailAdapter : RecyclerView.Adapter<EmailAdapter.EmailViewHolder>() {
    private var emails: List<String> = listOf()

    fun updateEmails(newEmails: List<String>) {
        emails = newEmails
        notifyDataSetChanged()
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): EmailViewHolder {
        val binding = ItemEmailBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return EmailViewHolder(binding)
    }

    override fun onBindViewHolder(holder: EmailViewHolder, position: Int) {
        holder.bind(emails[position])
    }

    override fun getItemCount(): Int = emails.size

    inner class EmailViewHolder(private val binding: ItemEmailBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(email: String) {
            binding.emailText.text = email
            
            // Copy button click
            binding.copyButton.setOnClickListener {
                animateCopyButton()
                copyEmailToClipboard(email, "Email copied to clipboard")
            }
            
            // Long press on the entire item
            itemView.setOnLongClickListener {
                it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
                animateCard()
                copyEmailToClipboard(email, "Email copied to clipboard (long press)")
                true
            }
        }
        
        private fun animateCopyButton() {
            val scaleX = ObjectAnimator.ofFloat(binding.copyButton, "scaleX", 1f, 0.8f, 1f)
            val scaleY = ObjectAnimator.ofFloat(binding.copyButton, "scaleY", 1f, 0.8f, 1f)
            AnimatorSet().apply {
                playTogether(scaleX, scaleY)
                duration = 200
                interpolator = OvershootInterpolator()
                start()
            }
        }

        private fun animateCard() {
            val scaleX = ObjectAnimator.ofFloat(itemView, "scaleX", 1f, 0.95f, 1f)
            val scaleY = ObjectAnimator.ofFloat(itemView, "scaleY", 1f, 0.95f, 1f)
            AnimatorSet().apply {
                playTogether(scaleX, scaleY)
                duration = 200
                interpolator = OvershootInterpolator()
                start()
            }
        }
        
        private fun copyEmailToClipboard(email: String, message: String) {
            val clipboard = itemView.context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("Email", email)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(itemView.context, message, Toast.LENGTH_SHORT).show()
        }
    }
}
