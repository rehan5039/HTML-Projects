package com.rr.emojiguru

import android.annotation.SuppressLint
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.os.Handler
import android.os.Looper
import android.provider.MediaStore
import android.util.Base64
import android.util.Log
import android.view.View
import android.view.WindowManager
import android.webkit.ConsoleMessage
import android.webkit.JavascriptInterface
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var webView: WebView
    private var backPressedTime: Long = 0
    private val BACK_PRESS_INTERVAL = 2000 // 2 seconds interval for double press

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        // Important: Make sure this is called BEFORE super.onCreate and setContentView
        // Switch from splash screen to app theme
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or 
                                                 View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        }
        
        super.onCreate(savedInstanceState)
        
        // Switch to the app theme after splash screen
        setTheme(R.style.Theme_EmojiGuru)
        
        // Create WebView programmatically
        webView = WebView(this)
        
        // Configure WebView settings
        val webSettings = webView.settings
        webSettings.javaScriptEnabled = true
        webSettings.domStorageEnabled = true
        webSettings.allowFileAccess = true
        webSettings.allowContentAccess = true
        webSettings.loadsImagesAutomatically = true
        webSettings.javaScriptCanOpenWindowsAutomatically = true
        webSettings.useWideViewPort = true
        webSettings.loadWithOverviewMode = true
        webSettings.databaseEnabled = true
        webSettings.setGeolocationEnabled(true)
        webSettings.allowUniversalAccessFromFileURLs = true
        webSettings.allowFileAccessFromFileURLs = true
        webSettings.cacheMode = WebSettings.LOAD_NO_CACHE
        
        // Handle mixed content properly based on Android version
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            webSettings.mixedContentMode = WebSettings.MIXED_CONTENT_ALWAYS_ALLOW
        }
        
        // Add JavaScript interface to handle downloads
        webView.addJavascriptInterface(WebAppInterface(this), "Android")
        
        // Configure WebChromeClient for JavaScript dialogs and console logs
        webView.webChromeClient = object : WebChromeClient() {
            override fun onConsoleMessage(consoleMessage: ConsoleMessage?): Boolean {
                Log.d("WebView", "${consoleMessage?.message()} -- Line ${consoleMessage?.lineNumber()} of ${consoleMessage?.sourceId()}")
                return true
            }
        }
        
        webView.setBackgroundColor(Color.parseColor("#f7f7f7"))
        
        // Configure WebViewClient for page navigation and JavaScript injection
        webView.webViewClient = object : WebViewClient() {
            @Deprecated("Deprecated in Java")
            override fun shouldOverrideUrlLoading(view: WebView, url: String): Boolean {
                view.loadUrl(url)
                return true
            }
            
            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
                    view.loadUrl(request.url.toString())
                }
                return true
            }
            
            override fun onPageStarted(view: WebView?, url: String?, favicon: Bitmap?) {
                super.onPageStarted(view, url, favicon)
                if (url?.contains("qrcode.html") == true) {
                    // Clear cache to ensure fresh rendering
                    webView.clearCache(true)
                }
            }
            
            override fun onPageFinished(view: WebView, url: String) {
                super.onPageFinished(view, url)
                
                // When emojimixer.html page is loaded, inject our JavaScript
                if (url.contains("emojimixer.html")) {
                    val jsInjection = """
                        javascript:(function() {
                            // Override the original downloadMixedEmoji function
                            window.downloadMixedEmoji = function() {
                                const dataUrl = canvas.toDataURL('image/png');
                                // Remove the prefix from the data URL to get the base64 string
                                const base64Data = dataUrl.split(',')[1];
                                // Call the Android interface to handle the download
                                Android.downloadImage(base64Data, 'mixed-emoji.png');
                            };
                            console.log('Download function overridden successfully');
                        })();
                    """.trimIndent()
                    
                    view.evaluateJavascript(jsInjection, null)
                }
                
                // When qrcode.html page is loaded, inject our JavaScript
                if (url.contains("qrcode.html")) {
                    // First ensure all scripts have fully loaded
                    Handler(Looper.getMainLooper()).postDelayed({
                        val qrCodeJsInjection = """
                            javascript:(function() {
                                console.log('QR Code page loaded, applying emoji fixes');
                                
                                // Override download QR Code functionality
                                window.downloadQRCode = function() {
                                    console.log('Custom download QR code function called');
                                    const qrcodeContainer = document.getElementById('qrcode');
                                    if (!qrcodeContainer) {
                                        console.error('QR code container not found');
                                        return;
                                    }
                                    
                                    // Create a canvas from the container
                                    const canvas = document.createElement('canvas');
                                    canvas.width = qrcodeContainer.offsetWidth;
                                    canvas.height = qrcodeContainer.offsetHeight;
                                    const ctx = canvas.getContext('2d');
                                    
                                    // Draw white background
                                    ctx.fillStyle = 'white';
                                    ctx.fillRect(0, 0, canvas.width, canvas.height);
                                    
                                    // Use html2canvas-like approach
                                    const elements = qrcodeContainer.querySelectorAll('*');
                                    Array.from(elements).forEach(el => {
                                        if (el.tagName === 'IMG') {
                                            ctx.drawImage(el, 0, 0, canvas.width, canvas.height);
                                        }
                                    });
                                    
                                    // Get the base64 string and download
                                    const dataUrl = canvas.toDataURL('image/png');
                                    const base64Data = dataUrl.split(',')[1];
                                    Android.downloadImage(base64Data, 'qrcode.png');
                                };
                                
                                // Replace the QR code generator with a modified version
                                if (typeof QRCode !== 'undefined') {
                                    // Store default generateQRCode function for later use
                                    const originalGenerateQRCode = window.generateQRCode;
                                    
                                    // Replace generateQRCode function
                                    window.generateQRCode = function() {
                                        console.log('Custom generateQRCode function called');
                                        
                                        // Get input content
                                        const inputType = document.getElementById('inputType').value;
                                        let qrContent = '';
                                        
                                        if (inputType === 'text') {
                                            qrContent = document.getElementById('textInput').value;
                                        } else {
                                            qrContent = document.getElementById('urlInput').value;
                                        }
                                        
                                        if (!qrContent) {
                                            alert('Please enter some content for the QR code');
                                            return;
                                        }
                                        
                                        const qrcodeContainer = document.getElementById('qrcode');
                                        qrcodeContainer.innerHTML = '';
                                        
                                        // Generate regular QR code with high error correction
                                        new QRCode(qrcodeContainer, {
                                            text: qrContent,
                                            width: 256,
                                            height: 256,
                                            colorDark: document.getElementById('foregroundColor').value,
                                            colorLight: document.getElementById('backgroundColor').value,
                                            correctLevel: QRCode.CorrectLevel.H
                                        });
                                        
                                        // Give the QR code time to render
                                        setTimeout(function() {
                                            // Get selected emoji
                                            const selectedEmoji = document.getElementById('selectedEmoji').value || '⬛';
                                            console.log('Using emoji: ' + selectedEmoji);
                                            
                                            // Find the generated QR code image
                                            const qrImage = qrcodeContainer.querySelector('img');
                                            if (!qrImage) {
                                                console.error('QR image not found');
                                                return;
                                            }
                                            
                                            // Create a new canvas element
                                            const canvas = document.createElement('canvas');
                                            canvas.width = qrImage.width;
                                            canvas.height = qrImage.height;
                                            const ctx = canvas.getContext('2d');
                                            
                                            // Draw the QR code on the canvas
                                            ctx.drawImage(qrImage, 0, 0);
                                            
                                            // Get the pixel data
                                            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
                                            const data = imageData.data;
                                            
                                            // Create a map of dark pixels (QR code modules)
                                            const darkPixels = [];
                                            const moduleSize = Math.floor(canvas.width / 25); // Approximate module size
                                            
                                            // Sample the pixels to find dark modules
                                            for (let y = 0; y < canvas.height; y += moduleSize) {
                                                for (let x = 0; x < canvas.width; x += moduleSize) {
                                                    const pixelIndex = (y * canvas.width + x) * 4;
                                                    if (data[pixelIndex] < 128) { // Dark pixel found
                                                        darkPixels.push({x: x, y: y});
                                                    }
                                                }
                                            }
                                            
                                            // Create a new canvas for emoji QR code
                                            const emojiCanvas = document.createElement('canvas');
                                            emojiCanvas.width = canvas.width;
                                            emojiCanvas.height = canvas.height;
                                            const emojiCtx = emojiCanvas.getContext('2d');
                                            
                                            // Draw white background
                                            emojiCtx.fillStyle = document.getElementById('backgroundColor').value;
                                            emojiCtx.fillRect(0, 0, emojiCanvas.width, emojiCanvas.height);
                                            
                                            // Draw emojis at dark pixel locations
                                            emojiCtx.font = moduleSize + 'px Arial';
                                            emojiCtx.textAlign = 'center';
                                            emojiCtx.textBaseline = 'middle';
                                            
                                            darkPixels.forEach(pixel => {
                                                emojiCtx.fillText(selectedEmoji, pixel.x + moduleSize/2, pixel.y + moduleSize/2);
                                            });
                                            
                                            // Replace the QR code image with our emoji version
                                            qrImage.src = emojiCanvas.toDataURL();
                                            
                                            // Show download button
                                            document.getElementById('downloadBtn').style.display = 'inline-block';
                                        }, 200);
                                    };
                                    
                                    // Make sure the download button uses our function
                                    const downloadBtn = document.getElementById('downloadBtn');
                                    if (downloadBtn) {
                                        downloadBtn.onclick = downloadQRCode;
                                    }
                                    
                                    // For immediate effect, generate QR code for any existing content
                                    const generateBtn = document.querySelector('button[onclick="generateQRCode()"]');
                                    if (generateBtn) {
                                        generateBtn.onclick = function() {
                                            window.generateQRCode();
                                        };
                                    }
                                    
                                    console.log('QR Code functionality successfully enhanced');
                                } else {
                                    console.error('QRCode library not found');
                                }
                            })();
                        """.trimIndent()
                        
                        view.evaluateJavascript(qrCodeJsInjection, null)
                    }, 1000) // Delay to ensure page is fully loaded
                }
            }
        }
        
        // Set WebView as the content view
        setContentView(webView)
        
        // Load index.html from assets folder
        webView.loadUrl("file:///android_asset/index.html")
    }
    
    override fun onBackPressed() {
        // Check if we're on the index page
        val currentUrl = webView.url
        if (currentUrl?.endsWith("index.html") == true) {
            // Handle double back press with confirmation dialog
            if (backPressedTime + BACK_PRESS_INTERVAL > System.currentTimeMillis()) {
                // Show confirmation dialog
                val builder = androidx.appcompat.app.AlertDialog.Builder(this)
                builder.setMessage("Do you want to exit the app?")
                    .setPositiveButton("OK") { _, _ ->
                        super.onBackPressed()
                    }
                    .setNegativeButton("Cancel") { dialog, _ ->
                        dialog.dismiss()
                    }
                builder.create().show()
            } else {
                // First back press - update timestamp and show toast
                backPressedTime = System.currentTimeMillis()
                Toast.makeText(this, "Press back again to exit", Toast.LENGTH_SHORT).show()
            }
        } else if (webView.canGoBack()) {
            webView.goBack()
        } else {
            super.onBackPressed()
        }
    }
    
    /** JavaScript Interface to handle communication between WebView and Android */
    inner class WebAppInterface(private val context: MainActivity) {
        @JavascriptInterface
        fun downloadImage(base64Data: String, fileName: String) {
            try {
                // Decode the base64 string to a bitmap
                val decodedBytes = Base64.decode(base64Data, Base64.DEFAULT)
                val bitmap = BitmapFactory.decodeByteArray(decodedBytes, 0, decodedBytes.size)
                
                // Save the bitmap to gallery
                val savedImageURL = MediaStore.Images.Media.insertImage(
                    context.contentResolver,
                    bitmap,
                    fileName,
                    "Image generated by Emoji Guru"
                )
                
                // Show success message
                context.runOnUiThread {
                    if (savedImageURL != null) {
                        Toast.makeText(context, "Image saved to gallery", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Failed to save image", Toast.LENGTH_SHORT).show()
                    }
                }
            } catch (e: Exception) {
                e.printStackTrace()
                context.runOnUiThread {
                    Toast.makeText(
                        context,
                        "Failed to save image: ${e.message}",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
        }
    }
} 