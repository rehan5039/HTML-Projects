package com.youbtrch.ybtbot

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
